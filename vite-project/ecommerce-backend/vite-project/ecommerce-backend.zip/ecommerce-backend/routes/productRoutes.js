import express from "express";
import { getProducts, addProduct } from "../controllers/productController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

// Public route - get all products
router.get("/", getProducts);

// Protected route - add a new product (requires login)
router.post("/add", protect, addProduct);

export default router;
