import Product from "../models/Product.js";

// ✅ Get all products
export const getProducts = async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (err) {
    console.error("Error fetching products:", err);
    res.status(500).json({ message: "Server error while fetching products" });
  }
};

// ✅ Add a new product
export const addProduct = async (req, res) => {
  const { name, description, price, image } = req.body;
  try {
    const product = await Product.create({ name, description, price, image });
    res.status(201).json(product);
  } catch (err) {
    console.error("Error adding product:", err);
    res.status(500).json({ message: "Server error while adding product" });
  }
};
