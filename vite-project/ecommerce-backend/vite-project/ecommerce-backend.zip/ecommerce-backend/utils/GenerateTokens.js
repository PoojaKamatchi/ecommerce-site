import jwt from "jsonwebtoken";

const GenerateTokens = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d",
  });
};

export default GenerateTokens; // this is very important
